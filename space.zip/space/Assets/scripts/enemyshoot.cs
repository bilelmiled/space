﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyshoot : MonoBehaviour
{
    public float timeb;
    public float nextshot= -1;
    public GameObject bullet;
    // Start is called before the first frame update
    void Start()
    {
        nextshot =5f;
        timeb=10f;
    }

    // Update is called once per frame
    void Update()
    {
        if(Time.time > nextshot)
        {
            Instantiate(bullet, transform.position,Quaternion.identity);
            nextshot = Time.time + timeb;
        }
    }
}
