﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class move : MonoBehaviour
{
        

    public GameObject bullet;
    Rigidbody2D rb;
    // Start is called before the first frame update
    void Start()
    {
        rb=bullet.GetComponent<Rigidbody2D>();
             //   ReplayButton.SetActive(false);

    }

    // Update is called once per frame
    void FixedUpdate()
    {
    GetComponent<Rigidbody2D>().velocity = Vector2.right * Input.GetAxisRaw("Horizontal") * 20;
    if(Input.GetKeyDown("space"))
    {
        rb.velocity = Vector2.up * 150;
        Instantiate(bullet,transform.position,Quaternion.identity);
    }
    }
     
}
